/**
 * @file API: Browsing History
 * @description Functions for collecting the browser's internal history if URLs
 * match targeted domains. Collects aggregate history items for matching URLs,
 * and then collects the individual visit items for each history item. Checks 
 * time of last data collection window before storing visit items to avoid large
 * data redundancies (i.e. collecting their entire history every time).
*/

/**
 * Browser History API Parameters.
 * @typedef {Object} BrowserHistory
 * @property {string} search A string to search for (empty string collects all).
 * @property {Array} domains The domains to collect history for.
 * @property {number} daysToGoBack Number of days to retrieve if initial load.
 * @property {number} daysToRecollect Number of days between collections.
 * @property {number} maxResults Maximum browsing history items.
 * @property {boolean} process Send data back to worker for post processing.
 */

/**
 * Get the browser history.
 * 
 * @param {Message} msg The message received from a worker.
 * @param {BrowserHistory} msg.params BrowserHistory API parameters
 */
function api_browser_history(msg) {
    console.log('Browser History API');

    let worker_id = msg.from
    let params = msg.api_params
    
    assert(params.api === 'browser_history', 'Message sent to wrong API')
    log_json(params)

    // Set time range to retrieve.
    let endTime = timestamp();
    let secsToGoBack = days_to_secs(params.daysToGoBack) 
    let startTime = (msg.state === 'init') ? endTime - secsToGoBack : msg.state;
    
    // Collect if time since last collection greater than data collection gap.
    if (endTime - startTime > days_to_secs(params.daysToRecollect)) {

        params['endTime'] = endTime
        params['startTime'] = startTime

        // Gets browing history through search API.
        chrome.history.search({
                text: params.search,
                startTime: params.startTime,
                endTime: params.endTime,
                maxResults: params.maxResults
            },
            function(historyItems) {
                console.log('History Items Found: ' + historyItems.length);
                process_browsing_history(historyItems, msg);
                storage.set(params.api, params.endTime);  // Updates state.
            }
        );
    } else {  // If refreshing too soon.
        console.log('Worker: This refresh is too close from last collection, skip!')
    }
}

/**
 * Filters and processes browsing history items.
 * 
 * @param  {Array} historyItems The history items found.
 * @param  {Message} msg The message being processed. 
 */
function process_browsing_history(historyItems, msg) {
    historyItems.forEach(function(historyItem){

        // Filter for valid domains.
        let valid_domains = msg.api_params.domains
        valid_url = has_match(historyItem.url, valid_domains)
        if (valid_url) {
            console.log('Found valid URL:', historyItem.url);
            get_visit_history(historyItem, msg);
        }
    });
}

/**
 * Gets an array of visitItems from historyItem.
 * 
 * @param  {Object} historyItem Summary of visits to a URL.
 * @param  {Message} msg The message being processed. 
 */
function get_visit_history(historyItem, msg) {
    chrome.history.getVisits({
            url: historyItem.url
        },
        function(visitItems) {
            process_visit_items(visitItems, historyItem, msg);
        }
    );
}

/**
 * Filters and sends visit items.
 * 
 * @param  {Array} visitItems The individual visit items for a URL.
 * @param  {Object} historyItem Summary of visits to a URL.
 * @param  {Message} msg The message being processed. 
 */
function process_visit_items(visitItems, historyItem, msg) {
    var params = msg.api_params
    
    // Filter out visit items from previous data collection windows
    var filteredVisitItems = visitItems.filter(
        function(visitItem) {
            if (visitItem['visitTime'] > params.startTime) {
                return visitItem;
            }
        }
    );

    let data = {
        historyItem: historyItem,
        visitItems: filteredVisitItems
    }

    message_server({
        to: 'server',
        from: 'background',
        suject: 'save',
        api: params.api,
        wid: msg.from,
        data: data
    });
}
