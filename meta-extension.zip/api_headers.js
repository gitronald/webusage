/**
 * @file API: Headers
*/

function api_headers(msg){
    console.log('Headers API');

    let worker_id = msg.from
    let params = msg.api_params
    
    assert(params.api === 'headers', 'Message sent to wrong API')
    log_json(params)

    chrome.webRequest.onBeforeSendHeaders.addListener(
        function listener(requestDetails) {
            watch_headers(requestDetails, msg)
        },
        {urls: ["<all_urls>"]},
        ["requestHeaders"]
    );
}

function watch_headers(requestDetails, msg) {
    
    let wid = msg.from
    let params = msg.api_params

    let self_init = 'chrome-extension://'

    // Reshape request details
    var data = {
        url: requestDetails.url,
        tab_id: requestDetails.tabId,
        initiator: requestDetails.initiator,
        timestamp: requestDetails.timeStamp,
        request_id: requestDetails.requestId,
        type: requestDetails.type,
        headers: {}
    }

    // Ignore extension requests
    if (!is_undefined(data.initiator) && (data.initiator.includes(self_init))) {
        return 
    } else if (data.url.includes(params.filter_url)) {

        // Convert from list of dict tuples to a dict 
        requestDetails.requestHeaders.forEach(function(header){
            var name = header.name.toLowerCase()
            data.headers[name] = header.value
        });

        // Send data if header matches
        if (params.filter_name == '' || params.filter_name in data.headers) {
            console.log('found header match')
            message_server({
                to: 'server',
                from: 'background',
                suject: 'save',
                api: params.api,
                wid: wid,
                data: data
            });
        }
    }
}