/**
 * @file API: Passive Monitor
 * @description Functions for passively monitoring browser windows and tabs,
 * with the option to take snapshots of pages based on string matching in URLs.
 * The granularity of the snapshot can be set to three options: "fine" records the raw HTML, "medium" records the title and all hyperlinks, and "coarse" only records the title.
 * 
*/

/**
 * Passive Monitor API Parameters.
 * @typedef {Object} Monitor
 * @property {string} granularity The level of detail to capture ['fine', 'medium', 'coarse'].
 * @property {Array} domains The domains to snapshot.
 * @property {boolean} process Send data to worker before saving.
 */

/**
 * Take a snapshot of the DOM on a new or existing tab.
 * @param {Message} msg The message received from a worker.
 * @param {Monitor} msg.params Passive Monitor API parameters
 */
function api_passive_monitor(msg) {
    console.log('Passive Monitoring API');

    var worker_id = msg.from
    var params = msg.api_params
    
    assert(params.api === 'passive_monitor', 'Message sent to wrong API')
    log_json(params)

    // Monitor the active browser tab
    chrome.tabs.query({
            active: true
        }, 
        function(tabs) {
            // Listen for changes
            chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
                
                // Window and Tab IDs
                let win_id = tab.windowId
                let tab_id = tab.id

                // Wait for tab to load
                if (tabId == tab.id && info.status == 'complete') {

                    // Check if URL is in allowed domains
                    valid_url = has_match(tab.url, params.domains);
                    if (valid_url) {

                        // Take snapshot
                        passive_snapshot(msg, win_id, tab_id);

                    // If no matching domain
                    } else {
                        
                        // Save meta data                        
                        let data = {
                            url: tab.url,
                            win_id: win_id,
                            tab_id: tab_id,
                            ts: isostamp()
                        }

                        message_server({
                            to: 'server',
                            from: 'background',
                            subject: 'save',
                            api: params.api,
                            wid: worker_id,
                            data: data
                        });
                    }
                }
            });
        }
    );
}
