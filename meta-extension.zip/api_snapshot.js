/**
 * @file API: Snapshot
*/

// TODO: add benign parameter to URLs so that they can be removed 
//       from browsing history


/**
 * Periodic Snapshot API Parameters.
 * 
 * @typedef {Object} PeriodicSnapshot
 * @property {Array} urls The URLs to snapshot.
 * @property {string} start_time The time to take the first snapshot.
 * @property {number} latency Milliseconds between each snapshot in a batch.
 * @property {number} interval Minutes between each batch of snapshots.
 * @property {string} granularity The level of detail to capture ['fine', 'medium', 'coarse'].
 * @property {boolean} process Send data to worker before saving.
 */

/**
 * Take a snapshot of the DOM on a new or existing tab.
 * 
 * @param {Message} msg The message received from a worker.
 * @param {PeriodicSnapshot} msg.params Periodic Snapshot API parameters
 */
function api_periodic_snapshots(msg) {
    console.log('Periodic Snapshot API');
    var params = msg.api_params;
    
    assert(params.api === 'periodic_snapshots', 'Message sent to wrong API')
    log_json(params)

    // Get start time in seconds.
    var start_time = new Date(params.start_time).getTime()

    // Create alarm.
    chrome.alarms.create('periodic_snapshots', {
        when: start_time, 
        periodInMinutes: params.interval
    });

    // Set alarm listeners.
    chrome.alarms.onAlarm.addListener(function(alarm){

        // Listen for set alarm.
        if (alarm.name === 'periodic_snapshots') {
            console.log('Alarm ['+alarm.name+'] fired at: ' + isostamp());
            snapshot_batch(msg)
        }
    });
}

/**
 * Create a new browser window
 * @param {Message} msg The {@link Message} to pass along.
 */
function create_window(msg, callback) {

    let params = msg.api_params

    chrome.windows.create({
        focused: false,
        incognito: params.incognito
    }, function(new_window) {
        callback(msg, new_window)
    });
}


/**
 * Create a new browser tab in a select window and pass message.
 * 
 * @param {Message} msg The {@link Message} to pass along.
 * @param {number} win_id The window to create the tab in.
 */
function create_tab(msg, win_id, callback) {

    let params = msg.api_params

    // Create new tab
    chrome.tabs.create({ 
        windowId: win_id,
        url: params.url,
        active: false
    }, function(tab) {
        // Do something with the new tab
        callback(msg, tab)
    });
}


/**
 * Take a snapshot of an open tab.
 * 
 * @param {Snapshot} params The API parameters
 * @param {number} window_id A window ID
 */
function passive_snapshot(msg, win_id, tab_id) {
    
    // Set API params
    let worker_id = msg.from;
    let params = msg.api_params;

    params['win_id'] = win_id;
    params['tab_id'] = tab_id;

    // Ask content script to take a snapshot
    message_content({
        to: 'content',
        from: worker_id,
        subject: 'snapshot',
        api_params: params
    });
}


/**
 * Open a new tab and take a snapshot when it loads.
 * 
 * @param {Message} msg The {@link Message} to process.
 * @param {number} win_id A window ID to create the tab in.
 */
function active_snapshot(msg, win_id) {
    
    let worker_id = msg.from;
    let params = msg.api_params;

    create_tab(msg, win_id, function(msg, tab) {

        // Listen for new tab to load
        chrome.tabs.onUpdated.addListener(
            function listener(tabId, changeInfo) {
                
                if (tabId == tab.id && changeInfo.status == 'complete') {
                    
                    // Take a snapshot
                    passive_snapshot(msg, win_id, tab.id);

                    // Store state and remove listener
                    storage.set(worker_id, timestamp());
                    chrome.tabs.onUpdated.removeListener(listener);
                }
            }
        );
    });
}


/**
 * Take a batch of snapshots and close window when done.
 * 
 * @param {Message} msg The {@link Message} to process.
 * @param {PeriodicSnapshot} msg.api_params The parameters to pass along.
 */
function snapshot_batch(msg) {
    log_json(msg);

    var worker_id = msg.from
    var params = msg.api_params

    log_json(params)

    // Create a new window
    create_window(msg, function(msg, new_window){
        
        // Define new window and tab ID
        let win_id = new_window.id
        let tab_id = new_window.tabs[0].id

        // Minimize window and display notification webpage.
        chrome.windows.update(win_id, { state: 'minimized' });
        chrome.tabs.update(tab_id, { url: 'pages/taking_snapshots.html' });

        // Define URL params
        let urls = params.urls;
        let n_urls = urls.length;
        let url_idx = 1

        urls.forEach(function(url){
            console.log('URL: ' + url_idx + '|' + url);

            // Close window on last url.
            let remove_win = (url_idx === n_urls);
            
            // Stagger wait times (otherwise all fire after `params.latency`)
            let wait_time = params.latency * (url_idx)

            // Set function to run after wait time passes
            setTimeout(function() {

                // Set params for url
                url_params = {
                    api: params.api,
                    granularity: params.granularity,
                    url: url,
                    win_id: win_id,
                    remove_tab: true,
                    remove_win: remove_win,
                    root_tab: tab_id
                }
                
                // Set message to pass along
                new_msg = {
                    to: msg.to, 
                    from: msg.from, 
                    api_params: url_params
                }

                // Snapshot HTML
                active_snapshot(new_msg, win_id);
                
            }, wait_time); // Wait 

            // Advance count
            url_idx += 1

        });
    });

}


// Depracated ------------------------------------------------------------------

/**
 * Snapshot API Parameters.
 * @typedef {Object} Snapshot
 * @property {string} url The URL to snapshot.
 * @property {string} granularity The level of detail to capture ['fine', 'medium', 'coarse'].
 * @property {boolean} new_window Create new window for snapshot.
 * @property {boolean} new_tab Create new tab for snapshot.
 * @property {boolean} remove_win Remove window after snapshot.
 * @property {boolean} remove_tab Remove tab after snapshot.
 * @property {boolean} incognito Make new window in incognito mode.
 * @property {boolean} process Send data to worker before saving.
 */

/**
 * Take a snapshot of the DOM on a new or existing tab.
 * @param {Message} msg The message received from a worker.
 * @param {Snapshot} msg.params Snapshot API parameters
 */
function api_snapshot(msg) {
    console.log('API: snapshot')

    var worker_id = msg.from
    var params = msg.api_params
    
    assert(params.api === 'snapshot', 'Message sent to wrong API')
    log_json(params)

    if (params.new_window || params.incognito) {

        // TODO: Check for allow extensions in incognito
        //  - Creating incognito will fail unless user manually sets option
        //  - Either check that option before creating the window
        //  - Or catch the error after it happens.
        //  - In either case, send user an alert to adjust setting. 
        
        // Create a new window
        create_window(msg, function(msg, new_window){
            // Define new window and tab ID
            let win_id = new_window.id
            let tab_id = new_window.tabs[0].id

            active_snapshot(new_msg, win_id);
        });

    } else {

        // Get current tab
        chrome.tabs.query({ currentWindow: true, active: true }, 
            function(tabs) {

                // Define IDs
                let active_tab = tabs[0];
                let win_id = active_tab.windowId;
                let tab_id = active_tab.id;

                // Create new tab or snapshot active tab
                if (params.new_tab) {
                    active_snapshot(msg, win_id);
                } else {
                    passive_snapshot(msg, win_id, tab_id)
                }
        });
    }
}