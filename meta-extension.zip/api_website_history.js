/**
 * @file API: Website History.
*/

// Object to hold user account login states
accounts = {
    google : {},
    facebook : {}
};

chrome.cookies.get({url:'https://accounts.google.com', name:'LSID'}, 
    function(cookie) {
        accounts.google.login = cookie ? true : false
        console.log('Cookie: ' + cookie)
    }
);

/**
 * Get the browser history.
 * 
 * @param {Message} msg The message received from a worker.
 */
function api_website_history(msg) {
    console.log('Website History API');

    let worker_id = msg.from
    let params = msg.api_params
    
    // assert(params.api === 'ad_preferences', 'Message sent to wrong API')
    log_json(params)

    // Send XHR request.
    perform_xhr(
        msg = msg,
        method = params.xhrMethod,
        url = params.xhrUrl + params.xhrParams,
        is_async = true,
        out_data = undefined
    );
    console.log('URL: ' + url);

    if (params.updateState) {
        storage.set(params.api, params.updateState);  // Updates state.
    }

    setTimeout(  // Wait for a while.
        function() {
            // Ask for next data.
            message_background({
                to: 'background',
                from: msg.from, 
                subject: 'api',
                api_params: params
            });
        },
        params.waitTime  // 10 seconds.
    )
}

// Generic function to send XHR requests.
function perform_xhr(
    msg,
    method,
    url,
    is_async,
    out_data
) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, is_async);
    xhr.onerror = function(e){
        console.log('XHR Error!');
    }
    xhr.onreadystatechange = function(e){
        process_requests(e, msg);
    }

    if (out_data === undefined){
        xhr.send();
    }
    else{
        xhr.send(out_data);
    }
}

// Process XHR requests on readyStateChange trigger.
function process_requests(e, msg) {

    let wid = msg.from
    let params = msg.api_params

    response = e.currentTarget.responseText;
    data = {html: response}

    message_server({
        to: 'server',
        from: 'background',
        suject: 'save',
        api: params.api,
        wid: wid,
        data: data
    });
}
