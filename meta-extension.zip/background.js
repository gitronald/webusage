/**
 * @file Background script that messages workers, content, and server.
*/

// Constants
var USER_ID = 'test_user'                           // User ID
var BROWSER_TYPE = 'chrome'                         // Browser type
// var SERVER_NAME = 'http://localhost:5000'           // Development server
var SERVER_NAME = 'http://3.134.77.215:80'   // Development server
var VERSION = chrome.runtime.getManifest().version  // Extension version

// Active workers
API_DICT = {
    "browser_history": api_browser_history,
    "passive_monitor": api_passive_monitor,
    "periodic_snapshots": api_periodic_snapshots,
    "google_activity": api_website_history
    // "ad_preferences": api_website_history
    // "headers": api_headers
}
worker_ids = Object.keys(API_DICT)


/**
 * Get worker state and send message. 
 * @param {Message} msg The {@link Message} to send.
 */
function message_worker(msg) {
    // Define worker
    let wid = msg.to

    // Get worker state and send message
    storage.get(wid, function(wid, result){
        msg.state = result
        workers[wid].worker.postMessage(msg);
    });
}

/**
 * Check permissions requested by a worker.
 * @param {Message} msg The {@link Message} to check.
 */
function check_permissions(msg) {
    console.log('Checking Permissions');
    assert("permissions" in msg, 'Missing permissions')
    
    // Define worker
    let wid = msg.from
    log_json(msg.permissions)

    // Hypothetically, check worker permissions here
    givePermission = true
    
    if (givePermission) {
        // Reply to worker and ask for data request
        message_worker({
            to: wid,
            from: 'background',
            subject: 'api'
        })
    }
}

/**
 * Call an API for a worker
 * @param {Message} msg The {@link Message} to send.
 */
function call_api(msg) {
    console.log('Calling API')
    assert("api_params" in msg, 'Missing API parameters')
    
    // Define worker and API
    let wid = msg.from
    let api_name = msg.api_params.api

    assert(is_defined(api_name), "No API specified")

    // Update state and call API
    storage.get(wid, function(wid, result){
        msg.state = result
        API_DICT[api_name](msg)
    });
}

/**
 * Message the content script on a specified tab
 * @param {Message} msg The {@link Message} to send.
 */
function message_content(msg){
    console.log('Messaging Content Script');

    // Define worker, tab, and API params
    log_json(msg)
    let wid = msg.from
    let params = msg.api_params
    let tab_id = params.tab_id

    // Send message to content script in a tab
    chrome.tabs.sendMessage(tab_id, msg,
        function(response){ 
            var data = response
            
            // Send data back to worker for processing
            if (params.process) {
                message_worker({
                    to: wid,
                    from: 'background',
                    subject: 'process',
                    api_params: params,
                    data: data
                });
            
            // Send data to server
            } else {
                message_server({
                    to: 'server',
                    from: 'background',
                    suject: 'save',
                    api: params.api,
                    wid: wid,
                    data: data
                });
            }

            // Close tab if specified
            if (params.remove_tab) {
                chrome.tabs.remove(tab_id);
            }

            // Close window
            if (params.remove_win) {
                console.log('Removing : ' + params.root_tab)
                chrome.tabs.remove(params.root_tab);
            }

        }
    );
}

/**
 * Send data to server
 * @param {Message} msg The {@link Message} to send.
 */
function message_server(msg) {
    server_url = SERVER_NAME + '/save_data'
    console.log('Sending data to: '+ server_url)
    log_json(msg)

    // Set constants
    out_data = {
        uid: USER_ID,
        browser: BROWSER_TYPE,
        version: VERSION,
        api: msg.api,
        wid: msg.wid,
        ts: isostamp(),
        data: msg.data
    }

    $.ajax({
        async: true,
        type: "POST",
        url: server_url,
        dataType: "json",
        data: jsonify(out_data),
        'Content-Type': "application/json",
        success: function(res) {
            console.log("data sent");
        },
        error: function(err) {
            console.log('Failed to send data to server')
            console.log(err)
        }
    });
}


// Workers ---------------------------------------------------------------------

workers = {}
worker_ids.forEach(function(wid) {
    
    // Load worker
    console.log('Loading worker: ' + wid)
    workers[wid] = {}
    workers[wid].fp = "workers/" + wid + "/worker.js"
    workers[wid].worker = new Worker(workers[wid].fp)
    
    // Get worker state from storage
    storage.get(wid, function(wid, result){

        // If undefined set to init(ialize) and update browser storage
        state = is_undefined(result) ? 'init' : result;
        if (state === 'init'){ storage.set(wid, state) }

        // Ask worker for permissions if init, else for data request
        message_worker({
            to: wid,
            from: 'background',
            subject: (state === 'init') ? 'permissions' : 'api'
        });

    });

    // Turn on listeners for worker messages
    workers[wid].worker.onmessage = function(event) {
        var msg = event.data
        assert(msg.to === 'background', 'Message sent to wrong script')
        log_json(msg)

        // Receive permissions request
        if (msg.subject === 'permissions') {
            check_permissions(msg)

        // Receive API request
        } else if (msg.subject === 'api') {
            call_api(msg)

        // Receive save request
        } else if (msg.subject === 'save') {
            message_server(msg)

        }
    }
});

// Popup -----------------------------------------------------------------------

chrome.runtime.onMessage.addListener(
    function(msg, sender, sendResponse){
        assert(msg.to === 'background', 'Message sent to wrong script')
        log_json(msg)

        let params = msg.api_params
        
        console.log('Received message from popup');
        log_json(msg)

        if (msg.subject === 'api') {
            call_api(msg)
        }
        sendResponse('hey popup');
    }
);
