/*
Content Script

Listens for messages from background and executes different operations on the
DOM depending on the message.
*/

/**
 * Extract values from a list of dicts
 * @param {Array} dicts A list of dicts
 * @param {string} key The key to use on each dict
 */
function extract_by_key(dicts, key) { 
    var values = []; dicts.forEach( function(d){ values.push(d[key]) });
    return values
}

/**
 * Check for matches, return true if no comparison list 
 * @param {string} item a string to compare
 * @param {Array} match_items an array to check for matches against
 */

function has_match(item, match_items) {
    if (match_items.length > 0) {
        return match_items.some(function(d) {return is_match(item, d)})
    } else {
        return true
    }
}

/**
 * Copy the Digital Object Model (DOM)
 * @param {Object} document The web page object
 */
function deep_copy(doc) {
    var dom = doc.querySelector('html');
    return doc.importNode(dom, deep=true); 
}

/**
 * Extract all links from a web page
 * @param {Object} document The web page object
 */
function extract_all_links(doc) {
    var elements = Array.from(doc.getElementsByTagName("a"));
    return extract_by_key(elements, 'href')
}

/**
 * Remove personally identifying information from Google Searches
 * @param {Object} document The web page object
 */
function remove_pii_google(document){
    // TODO, repeat function for FB, YouTube, and Twitter.
    return
}

// Listen for messages
chrome.runtime.onMessage.addListener(
    function(msg, sender, sendResponse) {

        // Set API params
        let params = msg.api_params
        
        if (msg.subject === 'snapshot') {
            let data = {
                "tab_id": params.tab_id,
                "win_id": params.win_id,
                "ts": isostamp(),
                "url": document.URL
            }

            if (msg.granularity === 'fine') {
                // msg["dom"] = deep_copy(document);
                data["dom"] = document.all[0].outerHTML
            
            } else if (params.granularity === 'medium') {
                data["title"] = document.title
                data["links"] = extract_all_links(document)

            } else if (params.granularity === 'coarse') {
                data["title"] = document.title
            }
            
            // Send message to requester
            sendResponse(data);

        }
    }
);
