class WorkerPostOffice {
    constructor(worker_id) {
        this.worker_id = worker_id;
    }

    /**
     * Put it in the mail - Sorts and sends a {@link Message}.
     * 
     * @param {Message} msg 
     */
    mail(subject, content) {
        
        // Create mesage to background
        var msg = {}
        msg.to = 'background'
        msg.from = this.worker_id
        msg.subject = subject
        msg.content = content
        this.message_background(msg)

    }
}


class WorkerPostOffice {
    constructor(worker_id) {
        this.worker_id = worker_id;
    }

    /**
     * Put it in the mail - Sorts and sends a {@link Message} to background.
     * 
     * @param {Message} msg 
     */
    to_background(subject, content) {
        
        // Check message address
        this.check_message(msg)
        this.message_background(subject, content)
    }

    /**
     * Check message for errors
     * 
     * @param {Message} msg Message from worker
     */
    check_message(msg){
        assert(msg.to === this.worker_id, 'Message sent to wrong worker')
        log_json(msg)
    }

    /**
    * Message background script.
    * 
    * @param {Message} msg Message from worker.
    */
    message_background(subject, content) {

        // Create message for background
        var msg = {}
        msg.to = 'background'
        msg.from = this.worker_id
        msg.subject = subject
        msg.content = content
        
        postMessage(msg) 
    };

}


class PostOffice {
    constructor(worker_id) {
        this.worker_id = worker_id;
    }

    /**
     * Put it in the mail - Sorts and sends a {@link Message}.
     * 
     * @param {Message} msg 
     */
    mail(msg) {
        if (msg.to === 'background'){
            this.message_background(msg)
        } else if (msg.to === 'content'){
            this.message_content(msg)
        } else if (msg.to === 'server'){
            this.message_server(msg)
        }
    }

    /**
     * Get worker state and send message. 
     * @param {Message} msg The {@link Message} to send.
     */
    message_worker(msg) {
        // Define worker
        let wid = msg.to

        // Get worker state and send message
        storage.get(wid, function(wid, result){
            msg.state = result
            workers[wid].worker.postMessage(msg);
        });
    }




    // Getter
    get area() {
        return this.calcArea();
    }
    // Method
    calcArea() {
        return this.worker_id;
    }
}



/**
 * Check permissions requested by a worker.
 * @param {Message} msg The {@link Message} to check.
 */
function check_permissions(msg) {
    console.log('Checking Permissions');
    assert("permissions" in msg, 'Missing permissions')
    
    // Define worker
    let wid = msg.from
    log_json(msg.permissions)

    // Hypothetically, check worker permissions here
    givePermission = true
    
    if (givePermission) {
        // Reply to worker and ask for data request
        message_worker({
            to: wid,
            from: 'background',
            subject: 'api'
        })
    }
}

/**
 * Call an API for a worker
 * @param {Message} msg The {@link Message} to send.
 */
function call_api(msg) {
    console.log('Calling API')
    assert("api_params" in msg, 'Missing API parameters')
    
    // Define worker and API
    let wid = msg.from
    let api_name = msg.api_params.api

    // Update state and call API
    storage.get(wid, function(wid, result){
        msg.state = result
        API_DICT[api_name](msg)
    });
}

/**
 * Message the content script on a specified tab
 * @param {Message} msg The {@link Message} to send.
 */
function message_content(msg){
    console.log('Messaging Content Script');

    // Define worker, tab, and API params
    log_json(msg)
    let wid = msg.from
    let params = msg.api_params
    let tab_id = params.tab_id

    // Send message to content script in a tab
    chrome.tabs.sendMessage(tab_id, msg,
        function(response){ 
            var data = response
            
            // Send data back to worker for processing
            if (params.process) {
                message_worker({
                    to: wid,
                    from: 'background',
                    subject: 'process',
                    api_params: params,
                    data: data
                });
            
            // Send data to server
            } else {
                message_server({
                    to: 'server',
                    from: 'background',
                    suject: 'save',
                    api: params.api,
                    wid: wid,
                    data: data
                });
            }

            // Close tab if specified
            if (params.remove_tab) {
                chrome.tabs.remove(tab_id);
            }

            // Close window
            if (params.remove_win) {
                console.log('Removing : ' + params.root_tab)
                chrome.tabs.remove(params.root_tab);
            }

        }
    );
}

/**
 * Send data to server
 * @param {Message} msg The {@link Message} to send.
 */
function message_server(msg) {
    server_url = SERVER_NAME + '/save_data'
    console.log('Sending data to: '+ server_url)
    log_json(msg)

    // Set constants
    out_data = {
        uid: USER_ID,
        browser: BROWSER_TYPE,
        version: VERSION,
        api: msg.api,
        wid: msg.wid,
        ts: isostamp(),
        data: msg.data
    }

    $.ajax({
        async: true,
        type: "POST",
        url: server_url,
        dataType: "json",
        data: jsonify(out_data),
        'Content-Type': "application/json",
        success: function(res) {
            console.log("data sent");
        },
        error: function(err) {
            console.log('Failed to send data to server')
            console.log(err)
        }
    });
}