
class Snapshot {
    constructor(url, granularity, new_window, incognito, process) {
        this.api = 'snapshot'
        this.url = url;
        this.granularity = granularity;
        this.new_window = new_window;
        this.incognito = incognito;
        this.process = process;
    }
    
    get_params() {
        console.log('getting params')
        return Object.getOwnPropertyNames(this);
    }

    check_params() {
        var params = this.get_params()
        console.log(params)
        params.forEach(function(param) {
            console.log(param)
            if (param != 'api') {
                assert(param in params, 'Missing required parameter: ' + param)
            }
        })
    }
}


class PostOffice {
    constructor(worker_id) {
        this.worker_id = worker_id;
    }

    mail_sorter(msg) {
        if (msg.to === 'background'){
            this.message_background(msg)
        }
    }

    /**
    * Message background script.
    * @param {Message} msg Message from worker.
    */
    message_background(msg) {
        postMessage(msg) 
    };

    /**
     * Check message for errors
     * @param {Message} msg Message from worker
     */
    check_message(msg){
        assert(msg.to === this.worker_id, 'Message sent to wrong worker')
        log_json(msg)
    }


    // Getter
    get area() {
        return this.calcArea();
    }
    // Method
    calcArea() {
        return this.worker_id;
    }
}