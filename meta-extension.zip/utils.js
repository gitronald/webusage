/* Utility functions and definitions */

/* Logging */
function jsonify(dict, rep, space) { return JSON.stringify(dict, rep, space) }
function log_json(dict) { console.log(jsonify(dict, null, 2)) }

/* Booleans */
function is_defined(obj) { return typeof obj != 'undefined'}
function is_undefined(obj) { return typeof obj === 'undefined'}
function is_function(obj) { return obj && typeof(obj) === "function" }

/* Time */
function isostamp() { return new Date().toISOString() }
function timestamp() { return new Date().getTime() }
function microtimestamp() { return timestamp() * 1000 }
function days_to_secs(n_days) { return n_days * 24 * 60 * 60 };
function days_to_microsecs(n_days) { return days_to_secs(n_days) * 1000 };
function iso_to_secs(isodate) { return new Date(isodate).getTime()}

// Make single (key, value) dict
function dict(k, v) {
    var d = {}
    d[k] = is_undefined(v) ? '' : v
    return d
}

/**
 * Assert condition
 * @param {Object} condition The boolean condition to assert.
 * @param {string} message The error message to raise.
 */
function assert(condition, message) {
    if (!condition) {
        message = message || "Assertion failed";
        if (typeof Error !== "undefined") {
            throw new Error(message);
        }
        throw message; // Fallback
    }
}

// String Matching -------------------------------------------------------------

// Check if item partially matches any item in a list
//*

function is_match(item, match_item) {
    return item.indexOf(match_item) > -1 ? true : false
}

/**
 * Check for matches, return true if no comparison list 
 * @param {string} item a string to compare
 * @param {Array} match_items an array to check for matches against
 */

function has_match(item, match_items) {
    if (match_items.length > 0) {
        return match_items.some(function(d) {return is_match(item, d)})
    } else {
        return true
    }
}

// State Storage ---------------------------------------------------------------

// Common root object for storage functions
var storage = {

    // Place data in storage with dict - e.g. ("myKey", value)
    set: function (key, value) {
        record = dict(key, value)
        chrome.storage.local.set(record,
            function () { console.log('Storage set: ' + jsonify(record)); }
        );
    },
    
    // Retrieve data from storage with key - e.g. "myKey"
    get: function(key, callback) {


        chrome.storage.local.get(key, 
            function(result) {
                var value = result[key]
                console.log('Storage get: ' + jsonify(dict(key, value)))
                if (is_function(callback)) {
                    callback(key, value);
                }
            }
        );
    }
};


// Worker Messaging ------------------------------------------------------------

/**
 * @typedef {Object} Message
 * @property {string} to The recipient of the message.
 * @property {string} from The sender of the message.
 * @property {string} subject The subject of the message.
 * @property {string} [state] The current worker state (added on send).
 * @property {Object} [permissions] Requested permissions (subject=permissions).
 * @property {Object} [api_params] Requested API parameters (subject='api').
 */

/**
 * Message background script
 * @param {Message} msg Message from worker
 */
function message_background(msg) { postMessage(msg) };

/**
 * Check message for errors
 * @param {Message} msg Message from worker
 */
function check_message(msg, worker_id){
    assert(msg.to === worker_id, 'Message sent to wrong worker')
    log_json(msg)
}

function receive_message(event) {
    // Receive and check message
    var msg = event.data
    check_message(msg, WORKER_ID)
    return msg
}
