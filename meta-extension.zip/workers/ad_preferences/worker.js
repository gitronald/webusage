/**
 * @file Worker: Ad Preferences
*/

importScripts('../../utils.js')
WORKER_ID = 'ad_preferences'

// Set permissions and API parameters
var permissions = {}
var params = {
    api: 'ad_preferences',
    adsUrls: [ // List of URLs to query to collect Ads preference.
        'https://o.bluekai.com/registry',  // Blue Kai.
        'https://adssettings.google.com/authenticated',  // Google Ads.
        'https://www.nielsen.com/us/en/privacy-statement/exelate-privacy-policy/opt-in-opt-out.html', // Exelate.
    ],  
    process: false
}

/**
 * 
 * @param {number} endTime Latest history time to collect
 * @param {string} xhrUrl The URL to get.
 */
function ad_preference_params(endTime, xhrUrl){
    var api_params = {
        api: 'ad_preferences',
        xhrMethod: 'GET',
        xhrUrl: xhrUrl,
        xhrParams: '',
        updateState: endTime,
        waitTime: days_to_secs(0.0001)  // Wait around 10 seconds.
    }
    return api_params
}

// Set ads preference options.
daysToRecollect = 7;  // Gap of days to recollect data (ie, not every refresh).

onmessage = function(event) {

    // Receive a message
    var msg = event.data
    check_message(msg, WORKER_ID)

    // Send message with permission request
    if (msg.subject === 'permissions') {
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'permissions',
            permissions: permissions
        });
    }
    
    // Permission accepted, sends message with data request.
    if (msg.subject === 'api') {
        
        // Set time range to retrieve.
        let endTime = timestamp();
        let startTime = (msg.state === 'init') ? 0 : msg.state;

        // If gap of days in satisfied.
        if (endTime - startTime > days_to_secs(daysToRecollect) ) {

            // Execute API on each Ad URL
            params.adsUrls.forEach(function(adsUrl){
                params = ad_preference_params(endTime, adsUrl)

                message_background({
                    to: 'background',
                    from: WORKER_ID, 
                    subject: 'api',
                    api_params: params
                });

            });
        } else {  // If refreshing too soon.
            console.log(WORKER_ID , 'Worker: This refresh is too close from last collection, skip!')
        }
    }

    // Send message with processed data
    if (msg.subject === 'process') {
        
        // TODO: Process the snapshot
        var processed = msg.data

        // Save processed data
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'save',
            api: params.api,
            wid: WORKER_ID,
            data: processed,            
        });
    }

};
