/**
 * @file Worker: Google Account Activity.
 * @description Saves Google account activity from webpage. Must be logged in.
*/

importScripts('../../utils.js')
var WORKER_ID = 'google_activity'

/**
 * 
 * @param {number} startTime Earliest history time to collect
 * @param {number} endTime Latest history time to collect
 */
function google_account_params(startTime, endTime){
    var api_params = {
        api: 'google_activity',
        xhrMethod: 'GET',
        xhrUrl: 'https://myactivity.google.com/myactivity',
        xhrParams: '?min=' + startTime + '&max=' + endTime,
        updateState: endTime,
        waitTime: days_to_secs(0.0001)  // Wait around 10 seconds.
    }
    return api_params
}

// Set permissions and API parameters
var permissions = {}
params = {
    initStartTime: 1579551277030000,  // Initial start time for Google activity.
    daysEachCollect: 1.5              // The time range of each collection.
}

// Receive a message
onmessage = function(event) {

    // Receive a message
    var msg = event.data
    check_message(msg, WORKER_ID)
    
    // Sends message with permission request.
    if (msg.subject === 'permissions') {
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'permissions',
            permissions: permissions,
            state: msg.state
        });
    }
    
    // Permission accepted, sends message with data request.
    if (msg.subject === 'api') {
        
        // Set time range to retrieve
        currentTime = microtimestamp();  // Now
        startTime = (msg.state === 'init') ? params.initStartTime : msg.state;
        endTime = startTime + days_to_microsecs(params.daysEachCollect)

        // If we have not collect all the history till now.
        if ( endTime < currentTime ) {
            console.log(WORKER_ID + ' : Collecting Google activity data.')
            // Send message with data request
            message_background({ 
                to: 'background',
                from: WORKER_ID, 
                subject: 'api',
                api_params: google_account_params(startTime, endTime)
            });
        } else {  // If all the history is collected till now.
            console.log(WORKER_ID, ' : All google activity is collected till now, skip!')
        }
    }

    // Send message with processed data
    if (msg.subject === 'process') {
        
        // TODO: Process the snapshot
        var processed = msg.data

        // Save processed data
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'save',
            api: params.api,
            wid: WORKER_ID,
            data: processed
        });
    }

};
