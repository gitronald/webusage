/**
 * @file Worker: Headers
 */

importScripts('../../utils.js')
var WORKER_ID = 'headers'

var permissions = {};
var params = {
    api: 'headers',
    filter_url: '',
    filter_name: '',
    process: false
}

onmessage = function(event) {
    
    // Receive a message
    var msg = event.data
    check_message(msg, WORKER_ID)

    // Send message with permission request
    if (msg.subject === 'permissions') {
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'permissions',
            permissions: permissions
        });
    }
    
    // Send message with data request
    if (msg.subject === 'api') { 
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'api',
            api_params: params
        });
    }

    // Send message with processed data
    if (msg.subject === 'process') {
        
        // TODO: Process the snapshot
        var processed = msg.data

        // Save processed data
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'save',
            api: params.api,
            wid: WORKER_ID,
            data: processed,            
        });
    }
};
