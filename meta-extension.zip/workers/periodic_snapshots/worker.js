/**
 * @file Worker: Active Monitor.
*/

importScripts('../../utils.js')
var WORKER_ID = 'periodic_snapshots'

// Note: if monitoring_start has already passed, will take snapshot on first load

/* Alarm Message
{
    alarm_name: "Google_News",              // Alarm name
    start_time: 'Nov 12 2019 23:46:00 EDT', // Alarm start time
    interval: 1,                            // Minutes between repeats
    repeats: 1,                             // Number of repeats
    api: "snapshot",                        // API to trigger
    url: "https://news.google.com"          // URL to capture
}
*/

var permissions = {}
var params = {
    api: 'periodic_snapshots',
    urls: [
        "https://news.google.com",
        "https://youtube.com", 
        "https://twitter.com"
    ],
    latency: 10000,
    start_time: 'Jan 21 2020 16:00:00 EDT',
    interval: 10,
    granularity: 'coarse',
    process: false
}

onmessage = function(event) {

    // Receive a message
    var msg = event.data
    check_message(msg, WORKER_ID)
    
    // Send message with permission request
    if (msg.subject === 'permissions') {
        message_background({
            to: 'background',
            from: WORKER_ID, 
            api: msg.api, 
            subject: 'permissions',
            permissions: permissions
        });
    }

    // Send message with data request
    if (msg.subject === 'api') { 
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'api',
            api_params: params
        });
    }

    // Send message with processed data
    if (msg.subject === 'process') {
        
        // TODO: Process the snapshot
        var processed = msg.data

        // Save processed data
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'save',
            api: params.api,
            wid: WORKER_ID,
            data: processed
        });
    }
};
