/**
 * @file Worker: Single Snapshot
*/

importScripts('../../utils.js')
var WORKER_ID = 'snapshot'

// Set permissions and API parameters
var permissions = {}
var params = {
    api: 'snapshot',
    url : 'http://ronalderobertson.com',
    granularity: 'fine', // ['fine', 'medium', 'coarse']
    incognito : false,
    new_tab : true,
    new_window : true,
    remove_tab: true,
    remove_win: true,
    process : true
}

onmessage = function(event) {
    
    // Receive a message
    var msg = event.data
    check_message(msg, WORKER_ID)
    
    // Send message with permission request
    if (msg.subject === 'permissions') {
        message_background({
            to: 'background',
            from: WORKER_ID,
            subject: 'permissions',
            permissions: permissions
        });
    }

    // Send message with data request
    if (msg.subject === 'api') { 
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'api',
            api_params: params
        });
    }

    // Send message with processed data
    if (msg.subject === 'process') {
        
        // TODO: Process the snapshot
        var processed = msg.data

        // Save processed data
        message_background({
            to: 'background',
            from: WORKER_ID, 
            subject: 'save',
            api: params.api,
            wid: WORKER_ID,
            data: processed
        });
    }
};
